#!/usr/bin/env bash

cd /hive/miners/custom/pmeer

. h-manifest.conf

CUSTOM_LOG_BASEDIR=`dirname "$CUSTOM_LOG_BASENAME"`
[[ ! -d $CUSTOM_LOG_BASEDIR ]] && mkdir -p $CUSTOM_LOG_BASEDIR

chmod -R 777 /hive/miners/custom/pmeer

mkdir /usr/lib64
cp -u /hive/miners/custom/pmeer/libcuckoo.so /usr/lib
cp -u /hive/miners/custom/pmeer/libcuckoo.so /usr/lib64
cp -u /hive/miners/custom/pmeer/libcudacuckoo.so /usr/lib
cp -u /hive/miners/custom/pmeer/libcudacuckoo.so /usr/lib64

(
	while true
	do 
		procnum=`ps -ef|grep "linux-miner"|grep -v grep|wc -l`
	   if [ $procnum -eq 0 ]; then
			timeout -k 1 300 ./pmeer -C pool.conf 
	   fi
	   sleep 1
	done
)  2>&1 | tee -a ${CUSTOM_LOG_BASENAME}.log