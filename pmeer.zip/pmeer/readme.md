# install lib

## ubuntu 
    copy libcuckoo.so to /usr/lib
    copy libcuckoo.so to /usr/lib64
    copy libcudacuckoo.so to /usr/lib
    copy libcudacuckoo.so to /usr/lib64

## mac
    copy libcuckoo.dylib to /usr/local/lib

## windows

    copy cuckoo.dll to C:/Windows/
    copy cudacuckoo.dll to C:/Windows/
    
## you need install drivers about opencl
    if have N cards can install cuda
    A cards can install Official driver 

## modify your config file `solo.conf`
- update your solo mining addr or pool account
- update your solo rpc server or pool address
- update your pow type 
- advanced can ajust the parameters
## run 

