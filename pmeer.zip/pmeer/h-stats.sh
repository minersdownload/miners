#!/usr/bin/env bash

get_hashrate(){
        local MH=$(grep speed ${LOG_NAME} | tail -n1 | perl -ne 'if (/Total hashrate ([0-9]) (([A-Z])MH\/s)/i) { print $1 * ($4 eq "G" ? 1000000 : ($4 eq "M" ? 1000 : 1)), "\n" }')
        [[ -z $MH ]] && MH=0
        echo "$MH"
}

get_shares(){
        local shares=$(grep accepted ${LOG_NAME} | tail -n1 | perl -ne 'if (/accepted\s+(\(([0-9]+)\/([0-9+])\))/i) { print "$2 $3\n" }')
        [[ -z $shares ]] && shares="0 0"
        echo "$shares"
}

get_miner_uptime(){
        ps -o etimes= -C $CUSTOM_NAME | awk '{print $1}'
}

get_log_time_diff(){
        local last_log=`tail -n 1 ${LOG_NAME} | awk {'print $1,$2'} | sed 's/[][]//g'`
        local last_log_unix=`date --date="$last_log" +%s`
        local cur_time_unix=`date +%s`
        echo `expr $cur_time_unix - $last_log_unix`
}

. /hive/miners/custom/$CUSTOM_MINER/h-manifest.conf

LOG_NAME="$CUSTOM_LOG_BASENAME.log"

local diffTime=$(get_log_time_diff)
local maxDelay=60

if [ "$diffTime" -lt "$maxDelay" ]
then
        local temp=$(jq -c ".temp" <<< $gpu_stats)
        local fan=$(jq -c ".fan" <<< $gpu_stats)

        [[ $cpu_indexes_array != '[]' ]] &&
                temp=$(jq -c "del(.$cpu_indexes_array)" <<< $temp) &&
                fan=$(jq -c "del(.$cpu_indexes_array)" <<< $fan)

        local shares=$(get_shares)
        local ac=$(cut -d " " -f1 <<< "$shares")
        local rj=$(cut -d " " -f2 <<< "$shares")

        local hr=$(get_hashrate)

        stats=$(jq -nc \
                --argjson hr "$hr" \
                --arg hs_units "MH" \
                --argjson temp "$temp" \
                --argjson fan "$fan" \
                --argjson uptime "$(get_miner_uptime)" \
                --argjson ac "$ac" \
                --argjson rj "$rj" \
                --arg algo "hns/bl2bsha3" \
                '{total_khs: $hr, hs: [], $hs_units, $temp, $fan, $uptime, ar: [$ac, $rj], $algo}')
        MH="$hr"
else
        stats=""
        MH=0
fi

[[ -z $MH ]] && MH=0
[[ -z $stats ]] && stats="null"

#echo "$stats"
#echo "$MH"
